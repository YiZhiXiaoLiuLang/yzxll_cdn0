import cv2,time,sys,requests,base64,json
from pyzbar.pyzbar import decode
from playsound import playsound
run_PATH=sys.path[0].replace('\\','/')+'/'
device_name='树莓派1号扫码枪'
host="http://127.0.0.1:80"
#bkshelfs={
#    '56890001':'阳台',
#    '56890002':'卧室A',
#    '56890003':'卧室B',
#    '56890004':'卧室B',
#    '56890005':'客厅白色玻璃门书架',
#    '56890006':'客厅旋转木书架',
#    '56890007':'客厅铁皮书架',
#    '56890008':'客厅矮白书架',
#    }
bkshelfs={}
with open("book_shelfs.json","r") as f:
    bkshelfs=json.load(f)
def read_bt():
    with open('button','r') as f:
        a=f.read()
        if(a==''):
            return 0
        else:
            return int(a)
def button_on():
    fst=time.time()
    if(read_bt()):
        time.sleep(0.05)#0.05秒内算抖动
        while(not read_bt()):
            if(time.time()-fst) >= 0.6:#0.6秒内按下算双击
                return 1
        return 2
def up_boot(isbn,img_list,pos):
    global device_name,host
    playsound(run_PATH+'sound/upload.mp3')
    print('upload',isbn,len(img_list),'image(s)')
    pic=[]
    for img_path in img_list:
        with open(img_path,'rb') as f:
            imagestr=str(base64.b64encode(f.read()))
            pic.append(imagestr[2:len(imagestr)-1])
    
    data={'action':'add_book',
          'ISBN':isbn,
          'pic':pic,
          'pos':pos,
          'from':device_name
          }
    #print(data)
    try:
        res=requests.post(host,data=json.dumps(data))
    except:
        playsound(run_PATH+'sound/upload_fail.mp3')
    else:
        playsound(run_PATH+'sound/okk.mp3')
    
    #playsound(run_PATH+'sound/upload_fail.mp3')
    
def main():
    bkshelf='未设置书架'
    wait_upload=[]
    imgname=0
    up_barcode_data = -1
    # 打开默认摄像头
    cap = cv2.VideoCapture(0)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
    #cap.set(cv2.CAP_PROP_AUTO_EXPOSURE, 0.25)  # 关闭自动曝光
    #cap.set(cv2.CAP_PROP_EXPOSURE, -13)  # 设置曝光值（范围：-13到-1，值越小曝光越低）
    #cap.set(cv2.CAP_PROP_CONTRAST, 60.0)  # 设置对比度值（默认为1.0） 
    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # 解码条码
        decoded_objects = decode(frame)
        #print(decoded_objects)
        
        for obj in decoded_objects:            
            # 获取条码的位置、类型和数据
            (x, y, w, h) = obj.rect
            barcode_data = obj.data.decode("utf-8")
            barcode_type = obj.type
            print('扫描到',barcode_data)
            if(len(barcode_data) <=6):#它..不太好用 总是把台灯识别成6位条码
                break
            
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cv2.putText(frame, f'{barcode_data} ({barcode_type})', 
                        (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 
                        0.5, (0, 255, 0), 2)
            if(len(barcode_data)==8):#书架,因为没有8位isbn
                if barcode_data in bkshelfs:
                    bkshelf=bkshelfs[barcode_data]
                    playsound(run_PATH+'sound/bookshelf.mp3')

            print(barcode_data)
            if(barcode_data== up_barcode_data):
                break
            playsound(run_PATH+'sound/decode_barcode.mp3')
            up_barcode_data=barcode_data
            
            print('take photo') 
            cv2.imwrite('output'+str(imgname)+'.jpg', frame)
            wait_upload.append('output'+str(imgname)+'.jpg')
            imgname+=1
            if bkshelf == '未设置书架':
                playsound(run_PATH+'sound/warning_bookshelf.mp3')
            # 在图像上绘制矩形和文本
            break#有的时候一个条码上面一条下面一条

        if button_on()==1:
            print('take photo')
            #单击
            #拍照
            playsound(run_PATH+'sound/takephoto.mp3')
            cv2.imwrite('output'+str(imgname)+'.jpg', frame)
            wait_upload.append('output'+str(imgname)+'.jpg')
            imgname+=1
        elif button_on()==2:
            #双击
            #上传
            up_boot(up_barcode_data,wait_upload,bkshelf)
            wait_upload=[]

        # 显示视频流
        cv2.imshow("Barcode Scanner", frame)

        # 如果按下 'q' 键，则退出循环
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # 释放摄像头并关闭窗口
    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    playsound(run_PATH+'sound/start.mp3')
    main()
