import _thread,keyboard,time
t=0
def write_bt(ch,chh):
    global t
    if ch:
        print(time.time()-t)
        t=time.time()
        
        print('touch',ch)
    with open('button','w') as f:
        f.write(str(ch))

        
keyboard.add_hotkey('alt+q', write_bt, args=(1,1))

while True:
    write_bt(0,0)
    time.sleep(0.1)
