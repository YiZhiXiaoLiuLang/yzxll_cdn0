from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import base64
from io import BytesIO
from PIL import Image
import time,os
import requests
isbn=9787830093136
headers = {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.51.4.19 Safari/537.36'
}
##返回(书名，作者，出版社，简介)
print("尝试方式二......",end='')
res=requests.get("http://www.zhuashu.cn/isbn/%isbn%".replace("%isbn%",str(isbn)),headers=headers)
if(res.status_code==200):
    print(res.text)
    #再烂我也给他洗干净
    fxxk=res.text.split(" <div class=\"fll\">")
    if len(fxxk)==1:
        #这个书库没有，嘻嘻
        raise
    else:
        fxxk=fxxk[-1].split('<p style="font-weight:bold; text-align:right;"> [来源:书号查询官网] </p>')[0]
        fk=fxxk.split('</li>')
        print(fk[0].split("<li>")[-1])
        print(fk[3].split("\n\t\t <li>")[-1])
        print(fk[4].split("\n\t\t <li>")[-1])
        print(fk[-1].split("<p>")[-1].split("</p>")[0])
        return fk[0].split("<li>")[-1],fk[3].split("\n\t\t <li>")[-1],fk[4].split("\n\t\t <li>")[-1],fk[-1].split("<p>")[-1].split("</p>")[0]
        
              
        
