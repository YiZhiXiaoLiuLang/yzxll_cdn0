from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import base64
from io import BytesIO
from PIL import Image
import time,os
import requests
headers = {
'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.51.4.19 Safari/537.36'
}
def save_b64img(b64,name):
    binary_data = base64.b64decode(b64)
    bytes_io = BytesIO(binary_data)
    image = Image.open(bytes_io)
    image.save(name)

    print("图像保存成功")
def stime():
    #'2024-10-01 23:41:51'
    return time.strftime("%Y-%m-%d-%H_%M_%S")
def download_book_name(isbn):
    print("查书",isbn)
    #isbn是int
    #返回(书名，作者，出版社，简介)
    try:
        '''
        {

            "code":0,
            "data": {
                "isbn": "9787830093136", "bookName":"算法竞赛进阶指南", "author":"李煜东", "press":"河南电子音像出版社", "pressDate":"2018-01-01",
                "pressPlace":"中原", "price":7900, "pictures":"[\"http://img3m9.ddimg.cn/51/14/11326384329-1_w_3.jpg\"]", "clcCode":"TP301.6-62",
                "clcName":"工业技术", "bookDesc":"本书主要根据CCF-NOI信息学奥林匹克竞赛涉及的知识体系进行编写，对计算机程序设计的基本技能——数据结构与算法进行了深入的讲解。",
                "binding":"平装", "language":"", "format":"16开", "pages":"492页", "edition":"", "words":""
            }

            ,
            "success":true
        }
        '''
        
    #方式一：https://data.isbn.work/openApi/getInfoByIsbn?isbn=9787830093136&appKey=ae1718d4587744b0b79f940fbef69e77
    #响应：
        print("尝试方式一......",end='')
        res=requests.get("https://data.isbn.work/openApi/getInfoByIsbn?isbn=%isbn%&appKey=ae1718d4587744b0b79f940fbef69e77".replace("%isbn%",str(isbn)))
        if(res.status_code==200):
            json=res.json()
            if json["success"] and json['data']["bookName"]!='' and json['data']["author"]!='':
                print("成功")
                noodle="信息来自isbn.work："+json['data']["clcName"]+','+json['data']["bookDesc"]+','+json['data']["format"]+','+json['data']["pages"]+','+json['data']["binding"]+','+json['data']["edition"]+','+json['data']["words"]

                return json['data']["bookName"],json['data']["author"],json['data']["press"],noodle
        #失败
        raise
    except:
        print("失败")



    print("尝试方式二......",end='')
    res=requests.get("http://www.zhuashu.cn/isbn/%isbn%".replace("%isbn%",str(isbn)),headers=headers)
    if(res.status_code==200):
        print(res.text)
        #再烂我也给他洗干净
        fxxk=res.text.split(" <div class=\"fll\">")
        if len(fxxk)==1:
            #这个书库没有，嘻嘻
            raise
        else:
            fxxk=fxxk[-1].split('<p style="font-weight:bold; text-align:right;"> [来源:书号查询官网] </p>')[0]
            fk=fxxk.split('</li>')
            #print(fk[0].split("<li>")[-1])
            #print(fk[3].split("\n\t\t <li>")[-1])
            #print(fk[4].split("\n\t\t <li>")[-1])
            #print(fk[-1].split("<p>")[-1].split("</p>")[0])
            return fk[0].split("<li>")[-1],fk[3].split("\n\t\t <li>")[-1],fk[4].split("\n\t\t <li>")[-1],fk[-1].split("<p>")[-1].split("</p>")[0]
            
                  
            


    
error_page = '''\
        <html>
       
        <head>
         <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>图书整理系统</title>
        </head>
        <body>
            <h1>加载失败</h1>
        </body>
        </html>
    '''
p_head='''
        <html>
        <head>
         <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
            <title>图书整理系统</title>
        </head>
        <body>
'''

p_end='''


        </body>
        </html>
'''
book_json=[]
def init():
    print("载入书库...",end='')
    global book_json
    with open('books-test.json','r',encoding='utf-8') as f:
        book_json=json.load(f)
    print('ok')
def sync(name,auther,press,isbn,desc):#这里desc传位置（客厅白色书架）
    global book_json
    book_json['result']['list'].append(
        {"bookname":name,
         "author": auther,
         "count": isbn,
         "publish": press,
         "price": desc,
         }
        )
    with open('books-test.json','w',encoding='utf-8') as f:
        json.dump(book_json,f)
            
    
def make(action):
    if action == 'index':
        booklist=[]
        with open('book.txt','r',encoding='utf-8') as f:
            
            while True:
                fp=f.readline()
                if fp == '':
                    #读完了
                    break
                booklist.append(fp.split('@'))
            Page=''
            for i in booklist:
                Page+='<a href=\"%hash%\">%book%</a><p>%msg%</p><br>'.replace("%hash%",i[0]).replace("%book%",i[1]).replace("%msg%",i[2])
    return p_head+Page+p_end
class MyHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers['Content-Length'])
        body = self.rfile.read(content_length)
        data = json.loads(body.decode('utf-8'))

        if data.get('action') == 'add_book':
            #格式{'action':'add_book','ISBN':ISBN,'pic':[base64_pic_0,base64_pic_1.....]}
            errcode=0
            ISBN = str(data['ISBN'])
            pic = data['pic']
            try:
                os.mkdir(ISBN)
            except:
                errcode=1
            

            for picture in pic:
                save_b64img(picture,ISBN+"/"+stime()+".png")
            data.pop('action')
            
            #data['name'],data['msg'] 俩都是str不是list
            data['name'],data['auther'],data['press'],data['msg']=download_book_name(data['ISBN'])
            with open(ISBN+"/"+'book.json','w',encoding='utf-8') as f:
                f.write(json.dumps(data))
            sync(data['name'],data['auther'],data['press'],ISBN,data['pos'])#这里desc传位置（客厅白色书架）
            response = json.dumps({'status': 'success', 'message': '录入成功'})
            
        elif data.get('action') == 'register':
            username = data.get('username')
            password = data.get('password')
            # 对注册请求进行处理

            response = json.dumps({'status': 'success', 'message': 'Registration successful'})
        else:
            response = json.dumps({'status': 'error', 'message': 'Invalid action'})

        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(response.encode())
    def do_GET(self):
        if(self.path=="/"):
            page=make('index')
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.send_header("Content-Length", str(len(page)))
            self.end_headers()
            self.wfile.write(page.encode('utf-8'))
        '''
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(response.encode())'''\

def run():
    init()
    server_address = ('', 80)
    httpd = HTTPServer(server_address, MyHTTPRequestHandler)
    print('Starting server...')
    httpd.serve_forever()

run()
