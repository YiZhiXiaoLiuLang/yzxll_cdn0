#制作by董乐山

#pip install pywin32

from PIL import Image, ImageDraw, ImageFont, ImageWin
import win32print
import win32ui

printers = win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)

print("可用打印机:")
for i, printer in enumerate(printers):
    print(f"{i + 1}: {printer[2]}")  # 打印机名称

# 选择打印机
printer_index = int(input("请输入打印机编号: ")) - 1

def split_string(s):
    return [s[i:i+12] for i in range(0, len(s), 12)]
def Print_58mmx30mm_SPRT_RMD11Axx(texts,fromm):
    global printer_index
    #texts = ["客厅大书架", "3排2列", "python从入门到入坟"]
    # 创建一个580x300的白色画布
    width, height = 360, 200
    canvas = Image.new('RGB', (width, height), 'white')
    draw = ImageDraw.Draw(canvas)
    print('来自',fromm)
    # 定义文字内容
    

    # 使用支持中文的字体
    font_size = 30
    font_path = "C:/Windows/Fonts/simhei.ttf"  # 示例：黑体
    font = ImageFont.truetype(font_path, font_size)
    # 计算每行的高度
    
    pt_wd=[]
    for i in texts:
        pt_wd+=split_string(i)
    texts=pt_wd
    
    line_height = height // len(texts)
    # 在每一行绘制文本
    for i, text in enumerate(texts):
        text_width, text_height = draw.textsize(text, font=font)
        x = (width - text_width) // 2  # 水平居中
        y = i * line_height + (line_height - text_height) // 2  # 垂直居中
        draw.text((x, y), text, fill='black', font=font)

    # 保存图像
    canvas.save('output.png')

    # 加载图像
    image_path = 'output.png'
    image = Image.open(image_path)

    # 列出可用的打印机
    printers = win32print.EnumPrinters(win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS)

    # 打印机选择
    print("可用打印机:")
    for i, printer in enumerate(printers):
        print(f"{i + 1}: {printer[2]}")  # 打印机名称

    # 选择打印机
    #printer_index = int(input("请输入打印机编号: ")) - 1
    printer_name = printers[printer_index][2]

    # 创建打印设备上下文
    hprinter = win32print.OpenPrinter(printer_name)
    dc = win32ui.CreateDC()
    dc.CreatePrinterDC(printer_name)
    dc.StartDoc(image_path)
    dc.StartPage()

    # 将图像绘制到打印机上
    width, height = image.size
    dib = ImageWin.Dib(image)
    dib.draw(dc.GetHandleOutput(), (0, 0, width, height))

    # 结束打印
    dc.EndPage()
    dc.EndDoc()
    dc.DeleteDC()
    win32print.ClosePrinter(hprinter)

    print("打印任务已发送！")
